/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","vi",{devTools:{title:"Thông tin thành ph",dialogName:"Tên hộp tho",tabName:"Tên th",elementId:"Mã thành ph",elementType:"Loại thành ph"}})